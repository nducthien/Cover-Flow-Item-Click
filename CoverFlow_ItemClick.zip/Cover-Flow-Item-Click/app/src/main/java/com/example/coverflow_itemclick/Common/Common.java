package com.example.coverflow_itemclick.Common;

import com.example.coverflow_itemclick.Model.Movie;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static List<Movie> movieList = new ArrayList<>();
    public static String MOVIE_INDEX = "movie_index";
}
